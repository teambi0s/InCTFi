#!/bin/bash

timeout 500 python /home/ctf/encrypt.py

