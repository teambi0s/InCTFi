<?php
session_start();
include("functions.php");

is_login();
is_admin();

$SANDBOX = getcwd() . "/uploads/" . md5("xxSpyD3rxx" . $_SERVER["REMOTE_ADDR"] . "xxxisbackxxx");
@mkdir($SANDBOX);
@chdir($SANDBOX);

if (isset($_FILES['file'])) {
  ExtractZipFile($_FILES['file']['tmp_name'], $SANDBOX);
  CheckDir($SANDBOX);
  echo "File is at: " . "/uploads/" . md5("xxSpyD3rxx" . $_SERVER["REMOTE_ADDR"] . "xxxisbackxxx");
}


?>
