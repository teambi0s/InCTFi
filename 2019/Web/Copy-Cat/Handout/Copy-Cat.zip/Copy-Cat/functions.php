<?php

session_start();
include("config.php");

function escape($str){
    global $conn;
    $str = $conn->real_escape_string($str);
    return $str;
}

function check($tocheck){
  $tocheck = trim(escape($tocheck));
  if(strlen($tocheck)<5){
    die("For God Sake, don't try to HACK me!!");
  }
  if(strlen($tocheck)>11){
    $tocheck = substr($tocheck, 0, 11);
  }
  return $tocheck;
}

function ExtractZipFile($file,$path){
  $zip = new ZipArchive;
  if ($zip->open($file) === TRUE) {
    $zip->extractTo($path);
    $zip->close();
}
}

function CheckDir($path) {
    $files = scandir($path);
    foreach ($files as $file) {
        $filepath = "$path/$file";
        if (is_file($filepath)) {
            $parts = pathinfo($file);
            $ext = strtolower($parts['extension']);
            if (strpos($ext, 'php') === false &&
                strpos($ext, 'pl') === false &&
                strpos($ext, 'py') === false &&
                strpos($ext, 'cgi') === false &&
                strpos($ext, 'asp') === false &&
                strpos($ext, 'js') === false &&
                strpos($ext, 'rb') === false &&
		strpos($ext, 'htaccess') === false &&
                strpos($ext, 'jar') === false) {
                @chmod($filepath, 0666);
            } else {
                @chmod($filepath, 0666);    // just in case the unlink fails for some reason
                unlink($filepath);
            }
        } elseif ($file != '.' && $file != '..' && is_dir($filepath)) {
            CheckDir($filepath);
        }
    }
}

function is_login(){
  if($_SESSION['logged']!=1){
    die("Login first");
  }
}

function is_admin(){
  if($_SESSION['admin']!="True"){
    die("Sorry, It seems you are not Admin...are you? If yes, proove it then !!");
  }
}

function send($random){
  $phone_number="xxxxxxxxxx";
  //Send random value to his phone number
}

?>
