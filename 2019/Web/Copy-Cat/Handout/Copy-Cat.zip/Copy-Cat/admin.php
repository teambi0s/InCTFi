<?php
include "functions.php";
session_start();

is_login();
is_admin();

?>
<!DOCTYPE html>
<html>
<head><title>File-Upload</title>
</head>
   <body>
     <h1>Welcome Admin, You can upload ZIP file here</h1>
      <form action = "upload.php" method="POST" enctype="multipart/form-data">
         <input type="file" name="file" />
         <input type="submit" name="submit" value="Upload" />
      </form>
        <p><a href='logout.php'>Log Out</a></p>
   </body>
</html>
